const express = require('express')
const mongoose = require('mongoose');
const router = express.Router();
const { MongoClient, GridFSBucket } = require('mongodb');
const userRoute = require("./routes/users.routes.js");
const postRoute = require("./routes/post.routes.js");
const FriendsRoute = require("./routes/friends.routes.js");
const fs = require('fs');


//Upload images
const multer = require("multer");
const path = require("path");


module.exports = router;
const app = express();
app.use(express.json());
const cors = require('cors'); 
const { getuid } = require('process');

app.use(cors({
    origin: 'http://localhost:4200' // Add your frontend URL here
}));

//Router
app.use("/api/Users", userRoute);
app.use("/api/Posts", postRoute);
app.use("/api/FriendsRequest", FriendsRoute);


app.get("/", (req, res) => {
  res.send("Hello from Node API Server Updated");
});

//3.7 version of node js is supporting other versions is not supporting
mongoose.connect('mongodb+srv://vankadaraniranjanidevi:rODDLsBUNhy27CdK@backenddb.hpfvgkl.mongodb.net/Node-API?retryWrites=true&w=majority&appName=BackEndDB',
{ useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    
    console.log('Connected! to the db');
    app.listen(3000,()=>{
        console.log('server is running on port 3000');
    });
})
  .catch((err)=>{ 
    console.log("Error received= " + err)    
});

//Upload images

// storage engine 
const storage = multer.diskStorage({
  destination: './Upload/Images',
  filename: (req, file, cb) => {
    const currentDate = new Date().toISOString().substr(0,13)+crypto.randomUUID();
//console.log('Formatted Date:', currentDate);
      return cb(null, `${file.fieldname}_${currentDate}${path.extname(file.originalname)}`)
  }
})

const upload = multer({
  storage: storage,
  limits: {
      fileSize: 10000000
  }
})
//upload image web method
app.use('/profile', express.static('Upload/Images'));
app.post('/post/upload', upload.single('profile'), (req, res) => {
    res.json({
        success: 1,
        username: req.body.username,        
        profile_url: `http://localhost:3000/profile/${req.file.filename}`
    })
})
//get single image as per file name
app.get('/post/images/:filename', (req, res) => {
  
  const filename = req.params.filename;
  //console.log(filename);
  console.log(__dirname + '/uploads/' + filename);
  res.sendFile(filename, { root: __dirname + '/Upload/Images' });
});

//getting all images names from fodler
const uploadFolder = path.join(__dirname, '/Upload/Images');

// Define a route to handle file listing
app.get('/post/postlist/:userName', (req, res) => {
    // Read the contents of the upload folder
    const userName = req.params.userName;
    //console.log(userName);
    fs.readdir(uploadFolder, (err, files) => {
        if (err) {
            console.error('Error reading folder:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }
        
        // Send the list of file names as a response
        res.json({ files });
    });
});


function errHandler(err, req, res, next) {
    if (err instanceof multer.MulterError) {
        res.json({
            success: 0,
            message: err.message
        })
    }
}
app.use(errHandler);
