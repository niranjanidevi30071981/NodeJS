const mongoose=require('mongoose');

const FriendsRequestSchema=mongoose.Schema({
    sourceUser:{
        type:String,
        required:[true,"sourceUser field is required"]
    },
    requestUser:{
        type:String,
        required:[true,"requestUser field is required"]
    },
    requestStatus:{
        type:String,
        required:[true,"requestStatus field is required"]
    } ,
    requestPending:{
        type:Boolean,
        required:[true,"requestPending field is required"],
        default:true
    } ,
    sendStatus:{
        type:Boolean,
        required:[true,"sendStatus field is required"],
        default:false
    } ,
    AcceptStatus:{
        type:Boolean,
        required:[true,"AcceptStatus field is required"],
        default:true
    } ,
    RejectStatus:{
        type:Boolean,
        required:[true,"RejectStatus field is required"],
        default:true
    }    
},
{
    timestamps:true
}
);

const FriendsRequest=mongoose.model('FriendsRequest',FriendsRequestSchema);

module.exports=FriendsRequest;


