const mongoose=require('mongoose');

const UserPostSchema=mongoose.Schema({
    firstname:{
        type:String,
        required:[true,"User Name field is required"]
    },
    postId:{
        type:Number,
        required:[true,"PostId field is required"]
    },
    postDescription:{
        type:String,
        required:[true,"postDescription field is required"]
    }
},
{
    timestamps:true
}
);

const UserPost=mongoose.model('UserPost',UserPostSchema);

module.exports=UserPost;


