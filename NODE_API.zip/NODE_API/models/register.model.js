const mongoose=require('mongoose');

const RegisterSchema=mongoose.Schema({
    firstname:{
        type:String,
        required:[true,"FirstName field is required"]
    },
    lastname:{
        type:String,
        required:[true,"LastName field is required"]
    },
    email:{
        type:String,
        required:[true,"Email field is required"]
    },
    password:{
        type:String,
        required:[true,"Password field is required"]
    },
    PhoneNo:String,
    DOB:{
        type:String,
        required:[true,"DOB field is required"],
        default:"07/30/1982"
    },
    gender:{
        type:String,
        required:[true,"Gender field is required"],
        default:"Female"
    },
    role:{
        type:String,
        required:[true,"Role field is required"],
        default:"Admin"
    },
    image:{
        type:String,
        required:[true,"Image field is required"],
        default:"../../assets/images/business.png"
    },
    address:{
        type:String,
        default:"Falt #1"
    },
    city:{
        type:String,       
        default:""
    },    
    state:{
        type:String,
        default:"Milton Keynes"
    },
    country:{
        type:String,       
        default:"United Kingdom"
    },
    accountBlock:{
        type:Boolean,       
        default:false
    }
},
{
    timestamps:true
}
);

const Register=mongoose.model('Register',RegisterSchema);

module.exports=Register;


