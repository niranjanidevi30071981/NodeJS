const express = require("express");
const router = express.Router();
const {createFriendsRequest,UpdateFriendsRequest,GetFriendsRequest,GetFriendsRequestasPerStatus,getConnectionsList} 
= require('../controller/friendsRequest.controller.js');

router.post("/:sourceUser/:requestUser/:requestStatus", createFriendsRequest);
router.put("/:sourceUser/:requestUser/:requestStatus", UpdateFriendsRequest);
router.get("/:sourceUser/:requestUser", GetFriendsRequest);
router.get("/:sourceUser/:requestUser/:requestStatus", GetFriendsRequestasPerStatus);
router.get("/:sourceUser", getConnectionsList);



//router.post("/ResetPassword/:firstname", resetPasswordUser);


module.exports = router;