const express = require("express");
const router = express.Router();
const {createUserPost} 
= require('../controller/post.controller.js');

router.post("/", createUserPost);

module.exports = router;

