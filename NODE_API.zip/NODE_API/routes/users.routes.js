const express = require("express");
const router = express.Router();
const {getUsers, getUser,getUserbyFirstName,forgotPasswordUser,resetPasswordUser, createUser, updateUser, deleteUser} 
= require('../controller/users.controller.js');

//User Routes
router.get('/', getUsers);
router.get("/:firstname/:password", getUser);
router.get("/:firstname", getUserbyFirstName);

router.post("/:firstname", createUser);
// update a product/api/Users
router.put("/:id", updateUser);
// delete a product
router.delete("/:id", deleteUser);
router.get("/ForgotPassword/:email/:DOB", forgotPasswordUser);
router.post("/ResetPassword/:firstname", resetPasswordUser);


module.exports = router;