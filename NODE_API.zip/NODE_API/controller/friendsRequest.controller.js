const NewFriendsRequest= require('../models/friendsRequest.model');
const express = require('express')
const bodyParser = require('body-parser');
const { param } = require('../routes/friends.routes');
const app = express();

//multiple parameters
app.use(bodyParser.json());

const createFriendsRequest=async (req, res) => {
    try
    {
      const{sourceUser}=req.params;
      const{requestUser}=req.params;
      const{requestStatus}=req.params;

      //console.log(req.params.requestUser);
      const GetfriendsList=await NewFriendsRequest.find({sourceUser:sourceUser}).find({requestUser:requestUser});//.
      
      if(!GetfriendsList.length)
      {
        req.body={"sourceUser":sourceUser, "requestUser":requestUser,"requestStatus":requestStatus}
        const RegisterUser=await NewFriendsRequest.create(req.body);
        res.status(200).json(RegisterUser);
          
      }
      else
      {
      
       const friendsRequest=await NewFriendsRequest.find({sourceUser:sourceUser}).find({requestUser:requestUser}).
        find({requestStatus:requestStatus});      
       
        if(friendsRequest.length>0)
        {
          return res.status(404).json({message: "we submited friend request"});
        }
        
      
      }
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };  

  
  const UpdateFriendsRequest= async (req, res)=>{
  try
  {
    
    const{sourceUser}=req.params;
      const{requestUser}=req.params;
      const{requestStatus}=req.params;      

      const friendsRequest=await NewFriendsRequest.find({sourceUser:sourceUser}).find({requestUser:requestUser});//.
      const id=friendsRequest[0]._id   
      // console.log(id);

        if(id)
        {        
          const Updatedresponse=await NewFriendsRequest.findByIdAndUpdate(id,req.body);
          if(!Updatedresponse)
          {
            return res.status(404).json({message: "User not Updated"});
          }
        }
        else
            return res.status(404).json({message: "User not found"});
       
        const UpdatedUser=await NewFriendsRequest.findById(id);
        res.status(200).json(UpdatedUser);
  } catch(err)
  {
   // console.log(err);
    res.status(500).json({message: err.message });
  } 
    
};

const GetFriendsRequest= async (req, res)=>{
  try
  {
    
    const{sourceUser}=req.params;
    const{requestUser}=req.params;         

      const friendsRequest=await NewFriendsRequest.find({sourceUser:sourceUser}).find({requestUser:requestUser});//.
      if(!friendsRequest.length)
      {
        const friendsRequestReevrse=await NewFriendsRequest.find({sourceUser:requestUser}).find({requestUser:sourceUser});

        return   res.status(200).json(friendsRequestReevrse); //res.status(404).json({message: "User not found"});
      }
      else
      {
        const id=friendsRequest[0]._id   
       // console.log(id);
        const UpdatedUser=await NewFriendsRequest.findById(id);
        res.status(200).json(UpdatedUser);
      }
      
  } catch(err)
  {
   // console.log(err);
    res.status(500).json({message: err.message });
  } 
    
};
  
const GetFriendsRequestasPerStatus= async (req, res)=>{
  try
  {
    
    const{sourceUser}=req.params;
      const{requestUser}=req.params;
      const{requestStatus}=req.params;

      //console.log(req.params.requestUser);
      const getfriendsList=await NewFriendsRequest.find({sourceUser:sourceUser}).find({requestUser:requestUser})
      .find({requestStatus:requestStatus});    

      if(!getfriendsList.length)
      {
        const friendsRequestReevrse=await NewFriendsRequest.find({sourceUser:requestUser}).find({requestUser:sourceUser})
        .find({requestStatus:requestStatus});  
        return   res.status(200).json(friendsRequestReevrse); //res.status(404).json({message: "User not found"});
      }
      else
      {
        const id=getfriendsList[0]._id   
       // console.log(id);
        const UpdatedUser=await NewFriendsRequest.findById(id);
        res.status(200).json(UpdatedUser);
      }
      
  } catch(err)
  {
   // console.log(err);
    res.status(500).json({message: err.message });
  } 
    
};


const getConnectionsList= async (req, res)=>{
  try
  {
    
    const{sourceUser}=req.params;
    console.log(sourceUser);
      const getfriendsList=await NewFriendsRequest.find({sourceUser:sourceUser})
      .find({requestStatus:'ACCEPT'});    

      if(!getfriendsList.length)
      {
        const friendsRequestReevrse=await NewFriendsRequest.find({requestUser:sourceUser})
        .find({requestStatus:'ACCEPT'});  
        return   res.status(200).json(friendsRequestReevrse); //res.status(404).json({message: "User not found"});
      }
      else
      {
        const id=getfriendsList[0]._id   
       // console.log(id);
        const UpdatedUser=await NewFriendsRequest.findById(id);
        res.status(200).json(UpdatedUser);
      }
      
  } catch(err)
  {
   // console.log(err);
    res.status(500).json({message: err.message });
  } 
    
};


module.exports = {
  createFriendsRequest,
  UpdateFriendsRequest,
  GetFriendsRequest,
  GetFriendsRequestasPerStatus,
  getConnectionsList
};

