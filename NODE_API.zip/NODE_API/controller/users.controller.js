const NewRegisterUser= require('../models/register.model');
const express = require('express')
const bodyParser = require('body-parser');
const app = express();
const jwt = require('jsonwebtoken');

//multiple parameters
app.use(bodyParser.json());

const getUsers=async (req, res) => {
    try
    {
      const registerUsers=await NewRegisterUser.find({});
      res.status(200).json(registerUsers);
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };  

 const getUserbyFirstName =  async (req, res) => {
    try
    {    
        const {firstname}=req.params;
        const  registerUsers= await NewRegisterUser.find({firstname:firstname});
        if(registerUsers)
        {         
            res.status(200).json(registerUsers);
        }
        else
        return res.status(404).json({message: "User not found"});
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };
  
const getUser =  async (req, res) => {
    try
    {    
        const {firstname}=req.params;
        const {password}=req.params; 
        const  registerUsers= await NewRegisterUser.find({firstname:firstname}).find({password:password}).
        find({accountBlock:false});
        if(registerUsers)
        {
          //console.log(registerUsers[0].image);
           const token= generateAccessToken(firstname);
           const ValidUser={auth:firstname,imageName:registerUsers[0].image,token:token,role:registerUsers[0].role}
           //console.log(ValidUser);
            res.status(200).json(ValidUser);
        }
        else
        return res.status(404).json({message: "User not found"});
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };
  

  function generateAccessToken(username) {
    //const jwt = require('jsonwebtoken');
    process.env.TOKEN_SECRET=require('crypto').randomBytes(64).toString('hex');
    //console.log(process.env.TOKEN_SECRET);
    return jwt.sign({ username }, process.env.TOKEN_SECRET, { expiresIn: '1800s' });
  }

const createUser =  async  (req,res)=>{
    try
    {
      const {firstname}=req.params;
      console.log(firstname);

      const registerUserslist=await NewRegisterUser.find({firstname:firstname});
      if(registerUserslist.length>0)
      {
        return res.status(404).json({message: "User already exists"});
      }
      
      //console.log(req.body);
      const RegisterUser=await NewRegisterUser.create(req.body);
      res.status(200).json(RegisterUser);
    }
    catch(err)
    {
      console.log(err);
      res.status(500).json({message: err.message });
    } 
  };

const updateUser = async (req, res)=>{
    try
    {
      const {id}=req.params;
      console.log(id);
      const User=await NewRegisterUser.findByIdAndUpdate(id,req.body);
      if(!User)
      {
        return res.status(404).json({message: "User not found"});
      }
      const UpdatedUser=await NewRegisterUser.findById(id);
      res.status(200).json(UpdatedUser);
    } catch(err)
    {
     // console.log(err);
      res.status(500).json({message: err.message });
    } 
      
  };

const deleteUser = async (req, res) => {
    try
    {
      const {id}=req.params;
      const User=await NewRegisterUser.findByIdAndDelete(id);
      if(!User)
      return res.status(404).json({message: "User not found"});
      
      res.status(200).json({message: "User Deleted Successfully"});
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };

  
//app.get('/api/Users/ForgotPassword/:email/:DOB', async (req, res) => {
  const forgotPasswordUser = async (req, res) => {
    try
    {    
        const {email}=req.params;
        const {DOB}=req.params; 
        //console.log(DOB);
        var parts =DOB.split('-');//2021-12-30'
        var formatDOB=parts[1]+'/'+parts[2]+'/'+parts[0];
       // console.log(formatDOB);
  
        const  registerUsers= await NewRegisterUser.find({email:email}).find({DOB:formatDOB});
        if(registerUsers)
        {          
            res.status(200).json(registerUsers);
        }
        else
        return res.status(404).json({message: "User not found"});
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };

//  app.post('/api/Users/ResetPassword/:firstname', async (req, res) => {
const resetPasswordUser = async (req, res) => {
    try
    {    
        const {firstname}=req.params;
        const {NewPassword}=req.params;     
  
        const User=await NewRegisterUser.find({firstname:firstname})
        const id=User[0]._id   
  
        if(id)
        {        
          const Updatedresponse=await NewRegisterUser.findByIdAndUpdate(id,req.body);
          if(!Updatedresponse)
          {
            return res.status(404).json({message: "User not Updated"});
          }
        }
        else
            return res.status(404).json({message: "User not found"});
       
        const UpdatedUser=await NewRegisterUser.findById(id);
        res.status(200).json(UpdatedUser);
    }
    catch(err)
    {
      res.status(500).json({message: err.message });
    }
  };
  

module.exports = {
    getUsers,
    getUser,
    getUserbyFirstName,
  createUser,
  updateUser,
  deleteUser,
  forgotPasswordUser,
  resetPasswordUser
  
};
