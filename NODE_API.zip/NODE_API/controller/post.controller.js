const UserPost= require('../models/userPosts.model');
const express = require('express')
const bodyParser = require('body-parser');

const app = express();
app.use(express.json());


const createUserPost=  async  (req,res)=>{
    try
    {
      const UserPostStatus=await UserPost.create(req.body);
      res.status(200).json(UserPostStatus);
    }
    catch(err)
    {
     // console.log(err);
      res.status(500).json({message: err.message });
    } 
  };
  module.exports = {
    createUserPost
  };

  app.post('/accept-friend-request/:requestId', async (req, res) => {
    try {
      const requestId = req.params.requestId;
      const friendRequest = await FriendRequest.findById(requestId);
  
      if (!friendRequest) {
        return res.status(404).json({ message: 'Friend request not found.' });
      }
  
      if (friendRequest.receiverId.toString() !== req.user.id) {
        return res.status(403).json({ message: 'Not authorized.' });
      }
  
      friendRequest.status = 'accepted';
      await friendRequest.save();
  
      // Update both users' friend lists here
      // ...
  
      res.status(200).json({ message: 'Friend request accepted.' });
    } catch (error) {
      res.status(500).json({ message: 'Server error.' });
    }
  });
  